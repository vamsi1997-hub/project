package com.qt.tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AddListing {
	@Given("user is launch the rentrola application")
	public void user_is_launch_the_rentrola_application() {
		
	   	}

	@When("user is click the search button")
	public void user_is_click_the_search_button() {
	  
	}

	@Then("user is search the hyderabad location rentals")
	public void user_is_search_the_hyderabad_location_rentals() {
	   
		
	}

	@Then("user click the hyderabad location rentals")
	public void user_click_the_hyderabad_location_rentals() {
	    
		
	}
   
}
