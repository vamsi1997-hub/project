package com.qt.tests;

import com.qt.driverinit.DriverInit;
import com.qt.testdata.Data;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Createasearch {
    DriverInit driver=new DriverInit();

	@When("user navigate to home page")
	
	@When("user click the create a search agent button")
	public void user_click_the_create_a_search_agent_button1() {
	   
	}

	@When("user give the valid email id")
	public void user_give_the_valid_email_id() {
	   
	}

	@When("user give the valid first name")
	public void user_give_the_valid_first_name() {
	   
	}

	@When("user give the city")
	public void user_give_the_city() {
	  
	}

	@When("user select the number of rooms")
	public void user_select_the_number_of_rooms() {
	   
	}

	@When("user give the rent amount")
	public void user_give_the_rent_amount() {
	   
	}

	@When("user select property type")
	public void user_select_property_type() {
	   
	}

	@When("user give the radius")
	public void user_give_the_radius() {
	    
	}

	@Then("user click the Create a search agent button")
	public void user_click_the_create_a_search_agent_button() {
	    
	}

}
